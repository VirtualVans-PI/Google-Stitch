---
name: Tia Cláudia Transporte Escolar
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#444650'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f1f1f1'
  outline: '#747782'
  outline-variant: '#c4c6d2'
  surface-tint: '#415ca1'
  primary: '#133377'
  on-primary: '#ffffff'
  primary-container: '#2f4b8f'
  on-primary-container: '#a8beff'
  inverse-primary: '#b2c5ff'
  secondary: '#0058be'
  on-secondary: '#ffffff'
  secondary-container: '#2170e4'
  on-secondary-container: '#fefcff'
  tertiary: '#003477'
  on-tertiary: '#ffffff'
  tertiary-container: '#014aa3'
  on-tertiary-container: '#a2bfff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2ff'
  primary-fixed-dim: '#b2c5ff'
  on-primary-fixed: '#001848'
  on-primary-fixed-variant: '#274387'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#adc6ff'
  on-secondary-fixed: '#001a42'
  on-secondary-fixed-variant: '#004395'
  tertiary-fixed: '#d8e2ff'
  tertiary-fixed-dim: '#aec6ff'
  on-tertiary-fixed: '#001a42'
  on-tertiary-fixed-variant: '#004396'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  title-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.5px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

O aplicativo atende pais, responsáveis e a equipe operacional da "Van da Tia Cláudia" em Sorocaba-SP. A atmosfera visual equilibra pontualidade, segurança institucional e acolhimento familiar. Pais entregam seus bens mais preciosos sob a responsabilidade do serviço; portanto, a interface deve transmitir controle em tempo real, previsibilidade e clareza instantânea, sem ruídos visuais ou infantilização excessiva.

Adota-se uma estética **Modern Material 3** calibrada para mobilidade urbana familiar:
- **Superfícies táteis e arejadas:** Fundo geral em tons neutros claros (#F2F2F2) intercalado com cartões brancos puros flutuantes e topos imersivos no gradiente corporativo.
- **Hierarquia direta:** Tipografia utilitária e nítida, badges semânticos de alta visibilidade e áreas de toque confortáveis para uso em trânsito ou na correria matinal.
- **Micro-interações sóbrias:** Transições suaves entre estados de embarque, trajeto e desembarque, eliminando ornamentos desnecessários em prol da precisão operacional.

## Colors

A paleta estrutura-se rigorosamente para garantir autoridade e acessibilidade cromática sob luz solar direta em telas de smartphones.

### Cores Principais e Gradiente
- **Azul Principal (`#2F4B8F`):** Identidade mestre, cabeçalhos de contexto, barras de navegação superiores e elementos de marca fundamentais.
- **Azul Interação (`#3B82F6`):** Gatilhos interativos primários, botões de ação principal (CTA), links ativos e seletores em foco.
- **Gradiente de Fundo Institucional:** Transição vertical de `#2E4A8D` para `#4A7BD6`, empregada no cabeçalho estendido do painel diário, tela de splash e cartões de destaque de rota em andamento.

### Superfícies e Neutros
- **Fundo de Aplicação / Secundário:** `#F2F2F2` (cinza suave que previne fadiga ocular e isola os blocos de conteúdo).
- **Fundo de Cartões / Superfície Pura:** `#FFFFFF` (foco absoluto da leitura de dados do aluno e status da van).
- **Campos de Entrada e Trilhas:** `#E5E7EB` (preenchimento padrão de inputs, barras de progresso inativas e separadores estruturais).

### Tipografia
- **Texto Principal:** `#1F2937` (contraste ótimo WCAG AAA sobre `#FFFFFF` e `#F2F2F2`).
- **Texto Secundário / Legendas:** `#6B7280` (rotulagem contextual, carimbos de hora e metadados).

### Cores Funcionais de Status Operacional
- **Informações Gerais:** `#1E88E5` (avisos de rotina, comunicados operacionais de Sorocaba).
- **Atenção / Suspensão:** `#FB8C00` (suspensão temporária de embarque pelo responsável, alerta de tráfego na rodovia/avenida).
- **Erros / Atrasos / Negados:** `#C9413F` (atraso na rota, ausência não programada, falha de validação).
- **Confirmações / Sucesso:** `#009951` (aluno embarcado, entregue na escola/residência com sucesso).
- **Situações Indefinidas / Inativas:** `#8E8E93` (aluno aguardando confirmação, rota não iniciada).

## Typography

A tipografia utiliza **Inter**, privilegiando escaneabilidade em interfaces móveis com densidade variável de dados (horários de parada, lista de presença, notificações push).

- **Headlines:** Usadas na recepção da tela inicial ("Olá, Família") e títulos de seções principais. `headline-lg-mobile` é o limite de leitura superior para dispositivos compactos.
- **Titles:** Empregados nos nomes de paradas, cartões de filhos/dependentes e tópicos de itinerário.
- **Body:** `body-md` serve como padrão de leitura para mensagens e descritivos de alertas. O `body-sm` é aplicado em notas de rodapé e observações de trânsito.
- **Labels:** Pesos de `600` com tracking ligeiramente aberto em `label-sm` garantem legibilidade imediata dentro dos badges de status operacional (ex: "EMBARCADO", "ATRASADO", "SUSPENSO").

## Layout & Spacing

O layout adota uma grade móvel de 4 colunas com calhas (`gutter`) de 16px (`1rem`) e margens laterais de segurança (`margin`) de 16px (`1rem`), expandindo para 24px em tablets compactos.

- **Filosofia de Espaçamento:** Baseada na métrica estrita de 8px (com sub-módulo de 4px para elementos compactos).
- **Áreas de Toque:** Nenhuma ação interativa, botão ou seletor de presença possui altura útil inferior a 48px, prevenindo toques acidentais por pais em movimento.
- **Ritmo de Agrupamento:**
  - Componentes internos relacionados (ícone + texto de status): `space-xs` (4px) a `space-sm` (8px).
  - Espaço interno de cartões (`padding`): `space-md` (16px) a `space-lg` (24px).
  - Distância entre blocos independentes de cartões na vertical: `space-md` (16px).
  - Folga antes de botões fixos de ação ou rodapés: `space-xl` (32px).

## Elevation & Depth

Alinhado ao Android Material 3, o sistema prioriza diferenciação tonal e sombras ambientes sutis, evitando efeitos artificiais pesados.

- **Nível 0 (Superfície Plana):** Fundo `#F2F2F2` da aplicação.
- **Nível 1 (Cartões Padrão e Listas):** Fundo `#FFFFFF`, sombra difusa com 4% a 6% de opacidade (`0px 2px 8px rgba(31, 41, 55, 0.05)`), sem borda ou com contorno quase imperceptível de 1px em `#E5E7EB`.
- **Nível 2 (Cartão de Destaque / Van em Rota):** Sombra suave `0px 4px 16px rgba(47, 75, 143, 0.12)`, criando relevo claro sobre a lista de horários.
- **Nível 3 (Barra de Navegação Inferior & Floating Actions):** Fundo `#FFFFFF`, com sombra ascendente `0px -4px 16px rgba(0, 0, 0, 0.06)`, mantendo foco constante sobre a área de toque dos polegares.
- **Modais e Bottom Sheets:** Superfície `#FFFFFF` ancorada na base com scrim escuro semi-transparente (`rgba(31, 41, 55, 0.40)`).

## Shapes

A curvatura empregada adota o padrão arredondado contemporâneo (nível 2), conferindo sensação amigável e segura.

- **Cartões Primários e Modais:** `rounded-2xl` (1rem / 16px) a `rounded-3xl` (1.5rem / 24px no caso de Bottom Sheets e cartões mestres da rota).
- **Campos de Entrada de Texto:** `rounded-xl` (0.75rem / 12px) para manter proporção agradável em alturas de 48px a 54px.
- **Botões de Ação:** `rounded-xl` (0.75rem / 12px) para botões utilitários e retangulares confortáveis; ou formato estritamente pílula (`full rounded`) exclusivo para chips de filtro e badges de status.
- **Imagens e Avatares de Alunos:** Círculos perfeitos com contornos protetivos em branco `#FFFFFF` de 2px quando sobrepostos no mapa ou listas.

## Components

### Botões
- **Primário:** Fundo em Azul de Interação `#3B82F6` com texto em `#FFFFFF`, altura mínima de 48px, peso semibold. Usado para "Confirmar Presença", "Avisar Embarque" ou "Salvar".
- **Secundário (Tonal / Neutro):** Fundo `#E5E7EB` com texto `#1F2937`. Usado para ações secundárias como "Detalhes da Parada" ou "Histórico".
- **Destrutivo / Emergência:** Fundo `#C9413F` ou contorno desse tom com texto correspondente para "Reportar Ausência" ou "Cancelar Rota".

### Badges de Status (Pílulas Operacionais)
Construídos em container suave (fundo pastel a 12-15% de opacidade) com texto e ícone no tom pleno correspondente:
- **Sucesso ("Embarcado" / "Entregue"):** Fundo `#E6F5ED`, texto `#009951`.
- **Atenção ("Ausente Hoje" / "Suspenso"):** Fundo `#FFF3E0`, texto `#FB8C00`.
- **Atraso / Alerta ("Trânsito" / "Atrasado"):** Fundo `#FAEBEA`, texto `#C9413F`.
- **Informativo ("A Caminho da Escola"):** Fundo `#E3F2FD`, texto `#1E88E5`.
- **Indefinido ("Aguardando Horário"):** Fundo `#F2F2F7`, texto `#8E8E93`.

### Cartões de Aluno e Rota
- Construídos em `#FFFFFF` sobre o canvas `#F2F2F2`, com cantos arredondados (`16px`), padding interno de 16px.
- Estrutura clara: Linha superior com avatar, nome da criança e escola em `#1F2937`; linha intermediária com endereço da parada e previsão de horário em `#6B7280`; linha inferior reservada para o badge de status e ação rápida de contato com a monitora/Tia Cláudia via WhatsApp/Telefone.

### Campos de Entrada (Inputs)
- Preenchimento em `#E5E7EB`, cantos em 12px, altura de 52px, sem bordas em repouso.
- Estado focado recebe borda de 2px em `#3B82F6` e fundo levemente clareado.
- Labels posicionadas acima do campo em `#6B7280` (`label-md`).

### Checkboxes e Controles de Presença
- Controles de alternância com área de toque mínima de 48x48px.
- Seleção ativa marcada no tom primário `#3B82F6` com ícone branco vívido de confirmação.

### Navegação Inferior (Bottom Navigation)
- Barra fixa em `#FFFFFF` com 4 destinos: **Início (Hoje)**, **Trajeto (Mapa)**, **Dependentes** e **Avisos**.
- Ícone ativo e rótulo no Azul Escuro Principal `#2F4B8F`, com indicador tonal arredondado em `#E3F2FD`. Destinos inativos em `#6B7280`.

### Cartão de Alerta Rápido no Topo
- Fixado logo abaixo do cabeçalho em gradiente quando houver imprevistos climáticos ou atrasos nas vias principais de Sorocaba (ex: Av. Dom Aguirre, Raposo Tavares). Fundo `#FFF3E0` com borda esquerda de 4px em `#FB8C00`.